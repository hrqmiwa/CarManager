# Relatório do Projeto CarManager

> Preencha este modelo e, se a escola pedir, exporte para PDF
> (`relatorio.pdf`) e coloque nesta pasta.

**Escola:** ETEC ______________  **Curso/Turma:** ______________
**Professor(a):** ______________  **Data:** ___/___/______

## Integrantes
- Nome: ______________________  RM: __________
- Nome: ______________________  RM: __________

## 1. Introdução e objetivo
(Explique o que é o CarManager e para que serve.)

## 2. Funcionalidades
(Liste o que o sistema faz: veículos, abastecimentos, manutenções, gastos, resumo.)

## 3. Como o sistema foi organizado
(Explique cada arquivo da pasta `src/` e por que o código foi dividido assim.)

## 4. Dificuldades encontradas
(O que foi mais difícil e como vocês resolveram.)

## 5. Testes realizados
(Descreva os testes manuais pelo menu e os testes automáticos em `tests/`.)

## 6. Conclusão
(O que vocês aprenderam e o que poderia melhorar.)
